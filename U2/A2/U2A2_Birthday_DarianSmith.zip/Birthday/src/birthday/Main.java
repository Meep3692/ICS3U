/*
Author: Darian
Date Modified: March 2, 2017
Program: User inputs name and birthday. When the button is pressed, it outputs [NAME]'s birthday is on [BIRTHDAY]
File: Main entry point, opens GUI
*/
package birthday;

class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GUI.main(args);
    }
    
}
